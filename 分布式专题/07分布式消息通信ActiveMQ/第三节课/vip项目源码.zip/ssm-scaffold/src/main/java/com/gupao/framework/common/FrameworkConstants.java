package com.gupao.framework.common;

import com.gupao.framework.common.utils.CharsetUtil;

/**
 * @author qingyin
 * @date 2016/8/19.
 */
public class FrameworkConstants {

    public final static String UTF_8 = CharsetUtil.UTF_8.name();

}
