package com.gupao.edu.commons.constants;

/**
 */
public class WxConstants {

    private static final String APPID="";

    private static final String APPSCRET="";

}
