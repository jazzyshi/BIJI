package com.gupao.vip.mic.dubbo.user;

import com.alibaba.dubbo.container.Main;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Main.main(args);
    }
}
