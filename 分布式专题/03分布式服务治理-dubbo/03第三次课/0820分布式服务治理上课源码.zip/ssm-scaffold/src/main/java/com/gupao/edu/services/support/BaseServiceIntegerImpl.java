package com.gupao.edu.services.support;

import com.gupao.framework.mybatis.AutoMapperInteger;
import com.gupao.framework.service.impl.SuperServiceIntegerImpl;

public class BaseServiceIntegerImpl<M extends AutoMapperInteger<T>, T> extends SuperServiceIntegerImpl<M, T> {

}
