package com.gupao.vip.mic.dubbo.order;

/**
 * 腾讯课堂搜索 咕泡学院
 * 加群获取视频：608583947
 * 风骚的Michael 老师
 */
public interface IOrderServices {

    /*
     * 下单操作
     */
    DoOrderResponse doOrder(DoOrderRequest request);

}
